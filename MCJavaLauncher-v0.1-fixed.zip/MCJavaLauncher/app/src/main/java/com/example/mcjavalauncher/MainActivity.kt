package com.example.mcjavalauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherScreen() }
    }
}

@Composable
fun LauncherScreen() {
    var status by remember { mutableStateOf("جاهز") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("MC Java Launcher", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(12.dp))
                Text("نسخة أولية — واجهة تشغيل Minecraft Java")
                Spacer(Modifier.height(28.dp))

                Button(
                    onClick = { status = "سيتم ربط محرك Java هنا في المرحلة التالية" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("تشغيل Minecraft Java") }

                Spacer(Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { status = "اختيار مجلد اللعبة سيضاف في المرحلة التالية" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("اختيار مجلد اللعبة") }

                Spacer(Modifier.height(24.dp))
                Text("الحالة: $status")
            }
        }
    }
}
